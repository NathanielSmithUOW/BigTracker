#include "editprofile.h"
#include "ui_editprofile.h"
#include <QDebug>
Editprofile::Editprofile(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Editprofile)
{
    ui->setupUi(this);
    User *u;
    int ID=2;
    if(connectToDatabase())
    {
        u = getUserFromID(ID);
        ui->editprofile_usernameLineEdit->setText(u->getUserName());
        ui->editprofile_fnameLineEdit->setText(u->getFirstName());
        ui->editprofile_lnameLineEdit->setText(u->getLastName());
        ui->editprofile_emailLineEdit->setText(u->getEmail());
    }
    closeDatabase();
}

Editprofile::~Editprofile()
{
    delete ui;
}

void Editprofile::on_editprofile_savePushButton_clicked()
{
    User *u;
    int ID=2;
    u=getUserFromID(ID);
    if(ui->editprofile_maleCheckBox->isChecked())
    {
        u->setGender("M");
    }
    if(ui->editprofile_femaleCheckBox->isChecked())
    {
        u->setGender("F");
    }
}
