#ifndef REGISTER_H
#define REGISTER_H

#include <QDialog>
#include "search.h"
#include <QtSql>
#include <QDebug>
#include "database.h"
#include "user.h"
namespace Ui {
class Register;
}

class Register : public QDialog
{
    Q_OBJECT

public:
    explicit Register(QWidget *parent = 0);
    ~Register();

private slots:


    void on_register_guestPushButton_clicked();

    void on_register_registerPushButton_clicked();

private:
    Ui::Register *ui;
    Search *search;
};

#endif // REGISTER_H
