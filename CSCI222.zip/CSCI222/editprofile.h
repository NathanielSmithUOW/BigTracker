#ifndef EDITPROFILE_H
#define EDITPROFILE_H

#include <QDialog>
#include "database.h"
#include "user.h"
namespace Ui {
class Editprofile;
}

class Editprofile : public QDialog
{
    Q_OBJECT

public:
    explicit Editprofile(QWidget *parent = 0);
    ~Editprofile();

private slots:
    void on_editprofile_savePushButton_clicked();

private:
    Ui::Editprofile *ui;
};

#endif // EDITPROFILE_H
