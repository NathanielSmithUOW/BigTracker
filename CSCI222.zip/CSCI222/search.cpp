#include "search.h"
#include "ui_search.h"

Search::Search(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Search)
{
    ui->setupUi(this);
    this -> setWindowTitle("Search");
}

Search::~Search()
{
    delete ui;
}
