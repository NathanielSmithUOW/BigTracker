#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPixmap>
#include <QMessageBox>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("Log In");
    QPixmap picture(":/img/img/Software-Bugs.png");
    int w=ui->logIn_picLabel->width();
    int h=ui->logIn_picLabel->height();
    ui->logIn_picLabel->setPixmap(picture.scaled(w,h,Qt::KeepAspectRatio));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_logIn_loginPushButton_clicked()
{
    QString email = ui->logIn_emailLineEdit->text();
    QString password = ui->logIn_pwdLineEdit->text();
    if(connectToDatabase())
    {
        if(checkLogin(email,password))
        {
            hide();
//            edit = new Editprofile (this);  //test
//            edit -> show();
            search = new Search (this);
            search -> show();
        }
        closeDatabase();
    }
    else
    {
        QMessageBox::warning(this,"warning","email or password is wrong!");
    }
}

void MainWindow::on_logIn_registerPushButton_clicked()
{
    newRegister = new Register (this);
    newRegister -> show();
}

void MainWindow::on_logIn_forgetpwdPushButton_clicked()
{
    forgetPassword = new ForgetPassword (this);
    forgetPassword -> show();
}
